#!/opt/homebrew/opt/python@3.11/bin/python3.11
"""Verify the authorized single-field output-label re-key of the accepted host restart."""
import hashlib, json, pathlib, sys
import f90nml
root = pathlib.Path('/private/tmp/c52-rd-ni-impurity-u3j07')
src = root/'immutable/Ni-bulk_U3_endpoint74_original.nml'
der = root/'immutable/Ni-bulk_U3_endpoint74_rekeyed.nml'
a, b = src.read_bytes(), der.read_bytes()
old = b"symbol = 'Ni-imp'"
new = b"symbol = 'Ni-bulk'"
if a.count(old) != 1 or b.count(new) != 1 or b != a.replace(old,new,1):
    raise SystemExit('rekey is not exactly the single authorized symbol replacement')
na, nb = f90nml.read(str(src)), f90nml.read(str(der))
na['element'].pop('symbol', None); nb['element'].pop('symbol', None)
if na != nb:
    raise SystemExit('parsed non-symbol namelist values differ')
record = {
  'record_type':'single_field_label_rekey_proof',
  'source_path':str(src),'source_sha256':hashlib.sha256(a).hexdigest(),
  'derived_path':str(der),'derived_sha256':hashlib.sha256(b).hexdigest(),
  'exact_replacement':"symbol = 'Ni-imp' -> symbol = 'Ni-bulk'",
  'count_in_source':a.count(old),'count_in_derived':b.count(new),
  'reverse_replacement_restores_source_bytes':b.replace(new,old,1)==a,
  'parsed_all_groups_equal_except_element_symbol':True,
  'source_symbol':'Ni-imp','derived_symbol':'Ni-bulk',
  'role':'derived host alias Ni-bulk_out.nml; original accepted state is also used byte-identically as Ni-imp_out.nml'
}
out=root/'immutable/host_rekey_proof.json'
out.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(record,sort_keys=True))
