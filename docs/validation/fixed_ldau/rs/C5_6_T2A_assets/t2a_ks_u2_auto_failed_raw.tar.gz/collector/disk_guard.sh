#!/bin/bash
set -euo pipefail
RUN=$1
SOLVER_PID=$2
FLOOR=1073741824
LOG="$RUN/disk_guard_events.jsonl"
available_bytes() { df -Pk "$RUN" | awk 'NR==2 {print $4 * 1024}'; }
printf '{"event":"guard_started","solver_pid":%s,"available_bytes":%s,"floor_bytes":%s}\n' "$SOLVER_PID" "$(available_bytes)" "$FLOOR" >> "$LOG"
while kill -0 "$SOLVER_PID" 2>/dev/null; do
  available=$(available_bytes)
  if [ "$available" -lt "$FLOOR" ]; then
    printf '{"event":"disk_floor","solver_pid":%s,"available_bytes":%s,"floor_bytes":%s,"action":"SIGTERM"}\n' "$SOLVER_PID" "$available" "$FLOOR" >> "$LOG"
    kill -TERM "$SOLVER_PID" 2>/dev/null || true
    exit 0
  fi
  printf '{"event":"periodic","solver_pid":%s,"available_bytes":%s,"floor_bytes":%s}\n' "$SOLVER_PID" "$available" "$FLOOR" >> "$LOG"
  sleep 2
done
printf '{"event":"solver_exit","solver_pid":%s,"available_bytes":%s}\n' "$SOLVER_PID" "$(available_bytes)" >> "$LOG"
