#!/bin/bash
set -euo pipefail
ROOT=/private/tmp/c57-t2a-ks-fe-auto-cont2
RUN="$ROOT/run"
CAPTURES="$ROOT/captures"
BIN="$ROOT/immutable/rslmto.x"
WATCHER="$ROOT/collector/watch_trace_and_state.py"
GUARD="$ROOT/collector/disk_guard.sh"
PYTHON=/opt/homebrew/opt/python@3.11/bin/python3.11
FLOOR=1073741824
RUN_ID=c57_t2a_cont2_ks_fe_u2_auto
sha256() { shasum -a 256 "$1" | awk '{print $1}'; }
available_bytes() { df -Pk "$RUN" | awk 'NR==2 {print $4 * 1024}'; }
[ ! -e "$RUN/solver.pid" ] && [ ! -e "$RUN/exit_code.txt" ] && [ ! -e "$RUN/lifecycle.txt" ] || { echo 'nonfresh lifecycle' >&2; exit 78; }
[ "$(sha256 "$BIN")" = 07a94dd35208ed7ace3b3c729f7d122e5771924265035a57606f7b84a446ea10 ] || { echo 'binary hash mismatch' >&2; exit 79; }
[ "$(sha256 "$RUN/input.nml")" = 1af5bcc4c3633f238043438e0aaa59575c8854f8fdbbd927af52f5660ae04083 ] || { echo 'deck hash mismatch' >&2; exit 81; }
[ "$(sha256 "$RUN/Fe_scf.nml")" = bb647254a5612f53d00e2745026c2cde32511f4363a1c7c3a1331d06573ead6b ] || { echo 'restart hash mismatch' >&2; exit 82; }
free=$(available_bytes); [ "$free" -ge "$FLOOR" ] || { echo "disk below floor before launch: $free" >&2; exit 85; }
printf '{"event":"preexec","available_bytes":%s,"floor_bytes":%s,"time":"%s"}\n' "$free" "$FLOOR" "$(date -Iseconds)" >> "$RUN/disk_guard_events.jsonl"
for key in OMP_NUM_THREADS OMP_DYNAMIC RSLMTO_OMP_THREADS_SERIAL OPENBLAS_NUM_THREADS MKL_NUM_THREADS VECLIB_MAXIMUM_THREADS BLIS_NUM_THREADS NUMEXPR_NUM_THREADS; do
  case "$key" in OMP_DYNAMIC) export "$key=FALSE" ;; *) export "$key=1" ;; esac
done
printf '%s\n' "launcher_pid=$$" "binary=$BIN" "binary_sha256=$(sha256 "$BIN")" "preexec_free_bytes=$free" "run_id=$RUN_ID" "started_local=$(date -Iseconds)" > "$RUN/lifecycle.txt"
"$PYTHON" "$WATCHER" --run-id "$RUN_ID" --solver-pid-file "$RUN/solver.pid" --run-dir "$RUN" --state-file Fe_scf.nml --output-dir "$CAPTURES" --ready-file "$RUN/watcher.ready" > "$RUN/watcher.log" 2>&1 &
watcher_pid=$!; printf '%s\n' "$watcher_pid" > "$RUN/watcher.pid"
for i in $(seq 1 1000); do
  [ -s "$RUN/watcher.ready" ] && break
  kill -0 "$watcher_pid" 2>/dev/null || { wait "$watcher_pid" || true; echo 'watcher exited before ready' >&2; exit 83; }
  sleep .1
done
[ -s "$RUN/watcher.ready" ] || { kill "$watcher_pid" 2>/dev/null || true; echo 'watcher readiness timeout' >&2; exit 84; }
free=$(available_bytes); [ "$free" -ge "$FLOOR" ] || { kill "$watcher_pid" 2>/dev/null || true; echo "disk below floor before solver: $free" >&2; exit 85; }
cd "$RUN"
env OMP_NUM_THREADS=1 OMP_DYNAMIC=FALSE RSLMTO_OMP_THREADS_SERIAL=1 \
  OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
  BLIS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \
  RSLMTO_FIXED_U_TRACE="$RUN/fixed_u_trace.csv" \
  RSLMTO_FIXED_U_RUN_ID="$RUN_ID" \
  RSLMTO_FIXED_U_TRACE_MOMENTS_ONLY=0 RSLMTO_FIXED_U_TRACE_QL_ONLY=0 \
  RSLMTO_FIXED_U_TRACE_ITERATION=0 RSLMTO_FIXED_U_TRACE_CAPTURE_ONLY=0 \
  RSLMTO_FIXED_U_A2_SCAN=0 "$BIN" > testrun.log 2>&1 &
solver_pid=$!; printf '%s\n' "$solver_pid" > "$RUN/solver.pid"; printf '%s\n' "$solver_pid" > "$RUN/solver_pid.actual"
printf '%s\n' "solver_pid=$solver_pid" "watcher_pid=$watcher_pid" "OMP_NUM_THREADS=1" "RSLMTO_OMP_THREADS_SERIAL=1" "library_thread_caps=1" "environment_recorded_local=$(date -Iseconds)" >> "$RUN/lifecycle.txt"
"$GUARD" "$RUN" "$solver_pid" > "$RUN/disk_guard.log" 2>&1 & guard_pid=$!; printf '%s\n' "$guard_pid" > "$RUN/disk_guard.pid"
rc=0; wait "$solver_pid" || rc=$?
printf '%s\n' "$rc" > "$RUN/exit_code.txt"
printf '%s\n' "exit_code=$rc" "ended_local=$(date -Iseconds)" >> "$RUN/lifecycle.txt"
kill "$guard_pid" 2>/dev/null || true; wait "$guard_pid" 2>/dev/null || true
wait "$watcher_pid" || true
exit "$rc"
